package com.prasanna.arrays;

import java.util.Arrays;

public class SecondMinAndSecondMaxInArray {

	public static void main(String[] args) {
		int[] arr = {2,5,4,1,6,9,7,8,3,10,15,15};
		secondMinAndSecondMax(arr);
		
	}

	private static void secondMinAndSecondMax(int[] arr) {
		int total = arr.length;
		int secondMax = 1;
		int secondMin = 1;
		Arrays.sort(arr);
		for(int i = total-1; i >0; i--) {
			if(arr[i] != arr[i-1])
				++secondMax;
			if(secondMax == 2) {
				System.out.println("Second Max in given array :- "+arr[i-1]);
				break;
			}
		}
		for(int i = 0; i < total; i++) {
			if(arr[i] != arr[i+1])
				++secondMin;
			if(secondMin == 2) {
				System.out.println("Second Min in given array :- "+arr[i+1]);
				break;
			}
		}
		
		
	}

}
