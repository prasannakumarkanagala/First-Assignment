package com.prasanna.arrays;

import java.util.Arrays;

public class SmallestPairSum {

	public static void main(String[] args) {
		 int[] arr = {1,0,3,7,6,4,9,10};
		 smallestPairSum(arr);
	}

	private static void smallestPairSum(int[] arr) {
		Arrays.sort(arr);
		int total = arr.length;
		if(total <2) {
			System.out.println("Invalid input, Required minimum 2 values in given array");
		}
		int pairSum = arr[0]+arr[1];
		System.out.println("Pair sum in given array :- "+pairSum);
	}
}
