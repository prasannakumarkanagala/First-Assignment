package com.prasanna.arrays;

import java.util.Arrays;

public class MinAndMaxElementsInArray {

	public static void main(String[] args) {
		int[] arr = {1,5,7,6,2,4,9,3,1,5,8,15};
		minAndMax(arr);
	}

	private static void minAndMax(int[] arr) {
		int total = arr.length;
		Arrays.sort(arr);
		System.out.println("Given array Min value :- "+arr[0]+ " Max value :-"+arr[total-1]);
	}

}
