package com.prasanna.arrays;

public class CommonElemntsAmong3Arrays {

	public static void main(String[] args) {
		int[] arr1 = {5,10,15,20,25,30};
		int[] arr2 = {2,6,10,9,20,16,19};
		int[] arr3 = {1,3,5,7,9,10,20};
		commonElement(arr1, arr2, arr3);
	}

	private static void commonElement(int[] arr1, int[] arr2, int[] arr3) {
		
		 int i = 0, j = 0, k = 0; 
		  
	        while (i < arr1.length && j < arr2.length && k < arr3.length) 
	        { 
	             if (arr1[i] == arr2[j] && arr2[j] == arr3[k])  {
	            	 System.out.print(arr1[i]+" ");  
	            	 i++; j++; k++; 
	            	 } 
	  
	             else if (arr1[i] < arr2[j]) 
	                 i++; 
	  
	             else if (arr2[j] < arr3[k]) 
	                 j++; 
	  
	             else
	                 k++; 
	        } 
	}

}
