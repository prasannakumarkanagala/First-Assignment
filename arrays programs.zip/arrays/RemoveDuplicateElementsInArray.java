package com.prasanna.arrays;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.stream.Collectors;

public class RemoveDuplicateElementsInArray {

	public static void main(String[] args) {
		Integer[] array = new Integer[] {1,2,4,2,5,1,4,7,7,9,2,5};
		System.out.println("Orgianl Array :- "+Arrays.toString(array));
		//Using Java8 Streams
		List<Integer> 	withOutDuplicates = Arrays.asList(array).stream().distinct().collect(Collectors.toList());
		System.out.println("Using Java Stream API :- "+withOutDuplicates);
		
		//Using Predefined Classes
		 LinkedHashSet<Integer> linkedHashSet = new LinkedHashSet<>( Arrays.asList(array) );
	        Integer[] numbersWithoutDuplicates = linkedHashSet.toArray(new Integer[] {});
	        System.out.println("Using Predefined Class :- "+ Arrays.toString(numbersWithoutDuplicates) );
		
		//Treditinal way
	        int[] treditinalArray = {1,5,2,2,4,6,5,1,9,4};
	        System.out.println("Treditianl Orginal Array :- "+Arrays.toString(treditinalArray));
	        Arrays.sort(treditinalArray);
	        int length = treditinalArray.length;
	        length = removeDuplicateElements(treditinalArray, length);
	        System.out.print("Using Treditinal approach");
	        for (int i=0; i<length; i++)  
	            System.out.print(treditinalArray[i]+" ");  
	}

	private static int removeDuplicateElements(int[] treditinalArray, int n) {
		 if (n==0 || n==1){  
	            return n;  
	        }  
	        int[] temp = new int[n];  
	        int j = 0;  
	        for (int i=0; i<n-1; i++){  
	            if (treditinalArray[i] != treditinalArray[i+1]){  
	                temp[j++] = treditinalArray[i];  
	            }  
	         }  
	        temp[j++] = treditinalArray[n-1];     
	        // Changing original array  
	        for (int i=0; i<j; i++){  
	        	treditinalArray[i] = temp[i];  
	        }  
	        return j;  
	}		
}
