package com.prasanna.arrays;

import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.stream.Collectors;

public class SumOfUniqueElementsInArray {

	public static void main(String[] args) {
		Integer[] array = new Integer[] {1,5,7,1,8,4,5,6,3,6,6,6};
		
		System.out.println("Orginal Array :- "+Arrays.toString(array));
		//Using Java Stream API
		IntSummaryStatistics sumOfUniqueElemnts = Arrays.asList(array).stream().distinct().collect(Collectors.summarizingInt(Integer::intValue));
		System.out.println("Unique Elements Using Java Stream API :- "+sumOfUniqueElemnts.getSum());
	
		int n = array.length;
		System.out.println("Unique elements sum :- "+findSum(array, n));
	
	}

	private static int findSum(Integer[] array, int n) {
		Arrays.sort(array);
		int sum = array[0]; 
        for (int i = 0; i < n-1; i++) { 
            if (array[i] != array[i + 1]) { 
                sum += array[i+1]; 
            } 
        } 
        return sum; 
		
	}
}
