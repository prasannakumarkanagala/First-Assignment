package com.prasanna.arrays;

import java.util.Arrays;

public class ThirdLargestNumberInArray {

	public static void main(String[] args) {
		 
		int[] array = {1,3,5,4,6,9,10,12,15,12,14,15,20,20};
		Arrays.sort(array);
		findThirdLargestNumber(array);
		
		
	}

	private static void findThirdLargestNumber(int[] array) {
		int thirdLargestIndex = 1;
		int total = array.length;
		if(total <3) {
			System.out.println("Invalid input");
		}
		
		for(int i = array.length-1; i >=0; i--) {
			if(array[i] != array[i-1]) {
				++thirdLargestIndex; 
				if(thirdLargestIndex ==3) {
					System.out.println("Third largest number in given array :- "+array[i-1]);
					return;
				}
			}
		}
		
	}

}
