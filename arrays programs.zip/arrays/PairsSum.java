package com.prasanna.arrays;

public class PairsSum {

	public static void main(String[] args) {
		 int[] arr = {3, 6, 8, -8, 10, 8 }; 
	        int sum = 16; 
	        getPairsCount(arr, sum); 

	}

	private static void getPairsCount(int[] arr, int sum) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if ((arr[i] + arr[j]) == sum) 
                	System.out.println("Pairs with Sum 16 are ("+arr[i]+", "+arr[j]+")");
            }
        }
	}

}
