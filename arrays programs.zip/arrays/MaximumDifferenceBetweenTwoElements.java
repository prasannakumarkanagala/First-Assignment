package com.prasanna.arrays;

import java.util.Arrays;

public class MaximumDifferenceBetweenTwoElements {

	public static void main(String[] args) {

		int[] arr = {1,2,6,7,3,9,4,3,6,8,10};
		maximumDifference(arr);
	}

	private static void maximumDifference(int[] arr) {
		Arrays.sort(arr);
		int total = arr.length;
		if(total <2) {
			System.out.println("Invalid input, Reqired atleast 2 elemnts in array..!");
			return;
		}
		int differnce = arr[total-1]-arr[0];
		System.out.println("Maximum differnce between two elements :- "+differnce);
		
	}

}
